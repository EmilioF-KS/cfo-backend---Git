package com.cfo.reporting;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CfoReportingApplicationTests {

	@Test
	void contextLoads() {
	}

}
