package com.cfo.reporting.drools.vlookup;

public class VLookupComponent {
}
