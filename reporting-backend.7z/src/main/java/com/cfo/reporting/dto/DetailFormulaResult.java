package com.cfo.reporting.dto;

public record DetailFormulaResult(String detailValue,String detailLabel,String formulaText,String columnName) {
}
