package com.cfo.reporting.dto;

public record CodeValueRec(String code,Double value) {
}
